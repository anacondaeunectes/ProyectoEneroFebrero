package Videoclub;

import java.time.LocalDate;

public class Alquiler {

	//FuncionCliente
	//FuncionProducto
	LocalDate fechaAlq;
	LocalDate fechaDev;
	double importe;
}
