package Videoclub;

public enum Plataforma {

	XBOX,
	PLAYSTATION,
	WII;
}
