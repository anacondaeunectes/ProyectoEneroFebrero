package Videoclub;

public enum Estilo {

	ACCION,
	DEPORTES,
	AVENTURAS,
	PUZZLE,
	INFANTIL;
}
