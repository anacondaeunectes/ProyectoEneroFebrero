package Videoclub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.Scanner;
import java.time.LocalDate;

/**
 * Esta clase contiene las funciones relacionadas con los objetos Pelicula
 */
public class FuncionPelicula {
	BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
	ArrayList<Pelicula> listaPelicula = new ArrayList<>();
	Excepcion ex = new Excepcion();
	
	FuncionPelicula(){}
	
	/**
	 * Metodo que crea y anade una pelicula a la coleccion de peliculas
	 */
	public void addPelicula() throws IOException {
		System.out.println("-ANIADIR PELICULA- \nTitulo de la pelicula");
		String titulo =  ex.soloTexto(teclado.readLine());;
		System.out.println("Anio:");
		int cont;
		int num = 0;
		String anio="";
		do {
			anio= ex.soloNumeros(teclado.readLine());
			int date= LocalDate.now().getYear();
		
			try {
				num=Integer.parseInt(ex.soloNumeros(anio));
				
			} catch (NumberFormatException e) {
				System.out.println("El a�o escrito no es valido");
			}
			
			if(num<1950 || num>(int)date) {
				cont=1;
				System.out.println("Anio no valido");
				
			}else {
				cont=0;
			}
		} while (cont==1);
		System.out.println("Director:");
		String director =  ex.soloTexto(teclado.readLine());
		System.out.println("Interpretes:");
		String interpretes =  ex.soloTexto(teclado.readLine());
		Boolean alquilado=false;
		System.out.println("Genero:\nOpcion 1 para Accion\nOpcion 2 para Drama\nOpcion 3 para Aventuras\nOpcion 4 para Infantil");
		Genero genero=null;
		int k;
		do {
			k= Integer.parseInt(ex.soloNumeros(teclado.readLine()));
		switch(k) {
			case 1:
				genero= Genero.ACCION;
				break;
			case 2: 
				genero= Genero.DRAMA;
				break;
			case 3:
				genero = Genero.AVENTURAS;
				break;
			case 4:
				genero = Genero.INFANTIL;
				break;
			default:
				System.out.println("Opcion no valida");
				break;
		}
		}while(k<=0 || k>4);
		System.out.println("Plazo de alquiler (Introduzca los dias):");
		int plazoAlquiler = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
		System.out.println("Precio (Si pone decimales, use un punto en vez de una coma):");
		double precioD=0;
		do {
			try {
				precioD=Double.parseDouble(teclado.readLine());
			} catch (NumberFormatException e) {
				System.out.println("Introduzca un precio correcto");
			}
		} while (precioD==0);
		listaPelicula.add(new Pelicula(titulo, precioD, plazoAlquiler, alquilado, genero, anio, director, interpretes));
	}
	
	/**
	 * Metodo que lista todas las peliculas de la coleccion Pelicula junto con su posicion en la coleccion
	 */
	public void listarPelicula(){
		Iterator<Pelicula> ite = listaPelicula.iterator();
		if (listaPelicula.isEmpty()) {
			System.out.println("No se han encontrado peliculas");
		}else {
			
			while (ite.hasNext()) {
				Pelicula p = ite.next();
				System.out.print(listaPelicula.indexOf(p) + 1);
				System.out.println(p.toString());
			}
		
		}
	}
	
	/**
	 * Metodo que ficha una pelicula, es decir, la describe. La pelicula que va a ser descrita es elegida primero.
	 */
	public void fichaPelicula() throws IOException {
		if (listaPelicula.isEmpty()) {
			System.out.println("No hay ninguna pelicula");
		}else {
			int opcion = 0;
			do {
				try {
					listarPelicula();
					System.out.println("Ponga el numero que identifique a la pelicula");
					opcion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
					
					System.out.println(listaPelicula.get(opcion - 1).toString());
				} catch (IndexOutOfBoundsException e) {
					System.out.println("Introduzca una opcion valida");
				}
			} while (opcion < 1 || opcion > listaPelicula.size());
			
				
		}
	}
	
	/**
	 * Metodo que permite elegir una pelicula para luego eliminarla de la coleccion de Peliculas
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public void eliminarPelicula() throws NumberFormatException, IOException {
		if (listaPelicula.isEmpty()) {
			System.out.println("No hay ninguna pelicula");
		}else {
			listarPelicula();
			System.out.println("Introduzca el identificador de la pelicula a eliminar: ");
			int c =Integer.parseInt(ex.soloNumeros(teclado.readLine())) - 1;
			listaPelicula.remove(c);
			System.out.println("Pelicula eliminada correctamente");	
		}
	}
}
