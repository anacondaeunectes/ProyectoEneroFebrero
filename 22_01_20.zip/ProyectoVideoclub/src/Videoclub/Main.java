package Videoclub;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
	
	static FuncionCliente FunCliente = new FuncionCliente();
	static FuncionPelicula FunPelicula = new FuncionPelicula();
	static FuncionVideojuego FunVideojuego = new FuncionVideojuego();
	static FuncionRegistroAlquiler FunRegistroAlquiler = new FuncionRegistroAlquiler();
	
	static BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
	static Excepcion ex = new Excepcion();
	
	public static void main(String[] args) throws IOException {
	
		
		int opcion;
		
		do {
			
			menu();
			
			opcion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
			
			switch (opcion) {
			
			case 0:
				System.out.println("Cerrando programa...");
				break;
				
			case 1:
				switch (elegirProducto()) {
				case 1:
					FunPelicula.listarPelicula();
					break;

				case 2:
					FunVideojuego.listarVideojuegos();
					break;
					
				default:
					System.out.println("Opcion no valida. Introduzca una opcion valida, por favor.");
					break;
				}
				break;
				
			case 2:
				switch (elegirProducto()) {
				case 1:
					FunPelicula.addPelicula();
					break;
					
				case 2:
					FunVideojuego.addVideojuego();
					break;
						
				default:
					System.out.println("Opcion no valida. Introduzca una opcion valida, por favor.");
					break;
				}
				break;
				
			case 3:
				switch (elegirProducto()) {
				case 1:
					FunPelicula.fichaPelicula();
					break;
				
				case 2:
					FunVideojuego.fichaVideojuego();
					break;
					
				default:
					System.out.println("Opcion no valida. Introduzca una opcion valida, por favor.");
					break;
				}
				break;
				
			case 4:
				switch (elegirProducto()) {
				case 1:
					FunPelicula.eliminarPelicula();
					break;
					
				case 2:
					FunVideojuego.eliminarVideojuego();
					break;
						
				default:
					System.out.println("Opcion no valida. Introduzca una opcion valida, por favor.");
					break;
				}
				break;
				
			case 5:
				FunCliente.listarCliente();
				break;
				
			case 6:
				FunCliente.ficharSoloCliente();
				break;
				
			case 7:
				FunCliente.addCliente();
				break;
				
			case 8:
				FunCliente.eliminarCliente();
				break;
				
			case 9:
				alquilar();
				break;
			
			case 10:
				FunRegistroAlquiler.listarRegistroAlquiler();
				break;
				
			default:
				System.out.println("Opcion no valida. Introduzca una opcion valida, por favor.");
				break;
			}
			
		System.out.println("");
			
		} while (opcion != 0);
		
	
	}
	
	/**
	 * Metodo que muestra un menu de cara a la eleccion de funcionalidades
	 */
	public static void menu() {
		
		System.out.println("GESTION VIDEOCLUB");
		System.out.println("=================");
		System.out.println("0. Salir del programa");
		System.out.println("1. Listado de productos");
		System.out.println("2. Anadir productos");
		System.out.println("3. Ficha de producto");
		System.out.println("4. Eliminar producto");
		System.out.println("5. Listado de clientes");
		System.out.println("6. Ficha de cliente");
		System.out.println("7. Anadir cliente");
		System.out.println("8. Eliminar cliente");
		System.out.println("9. Alquilar producto");
		System.out.println("10. Listado de los registros de alquiler");
		
	}
	
	/**
	 * Metodo que muestra las dos posibilidades de producto (pelicula y videojuego) y guarda el "int" correspondiente a la opcion elegida
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static int elegirProducto() throws NumberFormatException, IOException {
		
		System.out.println("Eliga el tipo de producto: ");
		System.out.println("1. Peliculas");
		System.out.println("2. Videojuegos");
		int opcion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
	
		return opcion;
	}
	
	/**
	 * Metodo que permite alquilar productos a clientes. Involucra tanto la eleccion del cliente como del producto ademas de crear y almacenar un registro cuando se produce el alquiler 
	 */
	public static void alquilar() throws IOException {
		
		Cliente ClienteTemporal = null;
		
		if (FunCliente.listaCliente.isEmpty()) {
			System.out.println("No hay ningun cliente");
		}else {
			FunCliente.listarCliente();
			System.out.println("Introduzca el identificador del cliente: ");
			int eleccion;
			boolean ok = true;
			do {
				eleccion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
				if (FunCliente.listaCliente.containsKey(eleccion)) {
					ClienteTemporal = FunCliente.listaCliente.get(eleccion);
					ok=true;
				}else {
					System.out.println("Cliente incorrecto. Vuelva a introducir otro cliente");
					FunCliente.listarCliente();
					ok=false;
				}
			} while (ok==false);
			
			switch (elegirProducto()) {
			case 1:
				
				if (FunPelicula.listaPelicula.isEmpty()) {
					System.out.println("No hay ninguna pelicula");
				}else {
					FunPelicula.listarPelicula();
					System.out.println("Introduzca el identificador de la pelicula: ");
					
					boolean aux = true;
					
					do {
						
						eleccion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
						
						if (eleccion <= ex.getSize(FunPelicula.listaPelicula) && eleccion > 0 ) {
							
							Pelicula peliculaTemporal = FunPelicula.listaPelicula.get(eleccion - 1);
							
							ClienteTemporal.addPelicula(peliculaTemporal);
							
							FunRegistroAlquiler.addRegistroPelicula(ClienteTemporal, peliculaTemporal);
							aux=true;
							
						}else {
							
							System.out.println("Codigo incorrecto, por favor introduzca otro");
							aux=false;
						}
					} while (aux==false);
				}
			
			break;
			
		case 2:
			
			
			
			
			if (FunVideojuego.listaVideojuego.isEmpty()) {
				System.out.println("No hay ningun videojuego");
			}else {
				FunVideojuego.listarVideojuegos();
				System.out.println("Introduzca el identificador del videojuego: ");
				
				boolean aux1= true;
				
				do {
					
					eleccion = Integer.parseInt(ex.soloNumeros(teclado.readLine()));
					
					if (eleccion <= ex.getSize(FunVideojuego.listaVideojuego) && eleccion > 0) {	
						
						System.out.println("Introduzca el identificador del videojuego:"); 
						Videojuego VideojuegoTemporal = FunVideojuego.listaVideojuego.get(eleccion - 1);
						
						ClienteTemporal.addVideojuego(VideojuegoTemporal);
						
						FunRegistroAlquiler.addRegistroVideojuego(ClienteTemporal, VideojuegoTemporal);
						
						aux1=true;
						
					}else {
						
						System.out.println("Codigo incorrecto, por favor introduzca otro");
						aux1=false;
					}
				} while (aux1==false);
			}
			
			break;
			
		default:
			break;
		}
		
	}
	
	}

}
