package Videoclub;

public enum Genero {

	ACCION,
	DRAMA, 
	AVENTURAS,
	INFANTIL;
}
